import { Component } from '@angular/core';
import { ProductModel } from './app.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  Id: any;
  productId: any = 0;
  constructor(public productModel: ProductModel) {}

  searchProduct(id) {
    this.productId = this.Id;
    this.productModel.positive = [];
    this.productModel.negative = [];
    this.productModel.neutral = [];
    this.productModel.getReviews(this.Id);
  }
}
